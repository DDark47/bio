# execute as @a if score @s in_tube matches 1 run effect give @s minecraft:water_breathing 2 255 true
# execute as @a if score @s in_tube matches 1 run effect give @s minecraft:regeneration 2 0 true
# execute as @a if score @s in_tube matches 1 run effect give @s minecraft:conduit_power 2 0 true
# execute if score miningfatigue config matches 1 as @a if score @s in_tube matches 1 run effect give @s minecraft:mining_fatigue 2 4 true
# execute if score nightvision config matches 1 as @a if score @s in_tube matches 1 run effect give @s minecraft:night_vision 11 255 true
execute as @a if entity @s[tag=ghosted] run effect give @s minecraft:invisibility infinite 0 true
execute as @a if entity @s[tag=ghosted] run effect give @s minecraft:saturation infinite 0 true
execute as @a if entity @s[tag=ghosted] run effect give @s minecraft:speed infinite 0 true
execute as @a if entity @s[tag=ghosted] run effect give @s minecraft:conduit_power infinite 0 true