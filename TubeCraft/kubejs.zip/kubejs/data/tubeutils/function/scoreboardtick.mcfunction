# execute if score world config matches 1 as @a run scoreboard players add @s in_tube 0
# execute as @a run scoreboard players add @s tbe_deaths 0
# execute as @a run scoreboard players add @s circuit_deaths 0
# execute if score world config matches 1 as @a if score @s in_tube matches 0 if entity @s[x=-30,y=-63,z=-30,dx=60,dy=126,dz=60,nbt={Dimension:"minecraft:overworld"}] run scoreboard players set @s in_tube 1
# execute if score world config matches 1 as @a if score @s in_tube matches 1 unless entity @s[x=-30,y=-63,z=-30,dx=60,dy=126,dz=60,nbt={Dimension:"minecraft:overworld"}] run scoreboard players set @s in_tube 0
# execute if score world config matches 1 as @a if entity @s[gamemode=survival] if entity @s[x=-2,y=62,z=-2,dx=4,dy=3,dz=4,nbt={Dimension:"minecraft:overworld"}] run tp @s 0 5 0
# execute as @a at @s if entity @s[tag=beneathvoid1] unless entity @s[nbt={Dimension:"codmod:raxxla"},x=0,y=250,z=0,distance=..150] in codmod:raxxla run tp 0 250 0
# execute as @a if entity @s[tag=beneathvoid1,name=!DDark47] run effect give @s minecraft:blindness 10 0 true

# execute as @a if entity @s[team=Corrupted,name=!DDark47] if score @s in_tube matches 1 run tp 87 88 399
# execute as @a if entity @s[team=!Voices,team=!Void] if score @s circuit_deaths matches 0 if score @s tbe_deaths matches 0 run team join Voices @s
# execute as @a if entity @s[team=Voices] if score @s circuit_deaths matches 1.. run team join Corrupted @s
# execute as @a if entity @s[team=Voices] if score @s tbe_deaths matches 1.. run team join Corrupted @s
execute store result bossbar minecraft:voltage value run data get entity @a[limit=1,team=Void] Health
# execute in minecraft:overworld as @a[distance=0..,tag=!overworldenabled] run execute in thebrokenlegacy:decayed run tp @s 13 128 41
# execute in thebrokenlegacy:dead as @a[distance=0..,tag=!overworldenabled] run kill @s

execute in thebrokenlegacy:decayed run spawnpoint @a 13 128 41
# execute if score world config matches 1 run function tubeutils:altartick
# execute if score entity_check config matches 1 run function tubeutils:entity_check
function tubeutils:glow_logic
# execute if score world config matches 2 run execute as @a run function tubeutils:in_facility_logic
# execute as @a if entity @s[tag=indignant] run stopsound @s * thebrokenscript:null_dimension_ambient

# execute as @a[tag=in_facility] at @s run fill ~-6 ~-6 ~-6 ~6 ~6 ~6 air replace #waystones:waystones