execute in thebrokenscript:day_b run setblock -3411 96 -3394 minecraft:respawn_anchor[charges=4] keep
execute in thebrokenscript:day_b run playsound minecraft:block.respawn_anchor.charge master @a -3411 96 -3394 10000

execute in thebrokenscript:day_b run setblock -3394 96 -3411 minecraft:respawn_anchor[charges=4] keep
execute in thebrokenscript:day_b run playsound minecraft:block.respawn_anchor.charge master @a -3394 96 -3411 10000

execute in thebrokenscript:day_b run setblock -3394 96 -3377 minecraft:respawn_anchor[charges=4] keep
execute in thebrokenscript:day_b run playsound minecraft:block.respawn_anchor.charge master @a -3394 96 -3377 10000

execute in thebrokenscript:day_b run setblock -3377 96 -3394 minecraft:respawn_anchor[charges=4] keep
execute in thebrokenscript:day_b run playsound minecraft:block.respawn_anchor.charge master @a -3377 96 -3394 10000
