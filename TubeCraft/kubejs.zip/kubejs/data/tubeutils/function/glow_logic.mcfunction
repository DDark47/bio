execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[gamemode=!survival]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[tag=ghosted]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[tag=voltage]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[tag=lowvoltage]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[tag=noglow]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}]
execute as @a if score @s glow_logic matches 0 store result score @s glow_logic if score nametag config matches 0
execute as @a if score @s glow_logic matches 1.. store result score @s glow_logic unless entity @s[team=Void]
execute as @a if score @s glow_logic matches 1.. run effect clear @s minecraft:glowing
execute as @a if score @s glow_logic matches 0 run effect give @s minecraft:glowing infinite 255 true
execute as @a run scoreboard players set @s glow_logic 0