// const { $ScoreAccess, $ScoreHolder } = require("@package/net/minecraft/world/scores")

let $ScoreAccess = Java.loadClass("net.minecraft.world.scores.ScoreAccess");
let $ScoreHolder = Java.loadClass("net.minecraft.world.scores.ScoreHolder");

/**
 * @param {$ScoreHolder} scoreHolder
 * @param {string} objective
 * @returns {$ScoreAccess}
 */
function getScore(scoreHolder, objective) {
    const { scoreboard } = scoreHolder
    return scoreboard.getOrCreatePlayerScore(scoreHolder, scoreboard.getObjective(objective)) ?? null
}

StartupEvents.registry('item', event => {
    event
        .create('zinc_dust')
        .texture('kubejs:item/zinc_dust')
        .maxStackSize(64)
        .tag([
            "c:dusts",
            "c:dusts/zinc"
        ])

    event
        .create('revival_star')
        .texture('minecraft:item/nether_star')
        .unstackable()
        .rarity('epic')
        .glow(true)
        .displayName('§4§lRevival Star')
        .tooltip("§c§oA corrupted player may use this to restore their vigor")
        .color(itemstack => itemstack.nbt && itemstack.nbt.color ? itemstack.nbt.color : Color.DARK_RED)
        .fireResistant(true)
        .useAnimation("bow")
        .useDuration((itemstack) => 64)
        .use((level, player, hand) => true)
        .finishUsing((itemstack, level, entity) => {
            try {
                if (entity.isPlayer() && entity.getTeamId() === "Corrupted") {
                    entity.kill()
                    getScore(entity, "tbe_deaths").set(0)
                    getScore(entity, "circuit_deaths").set(0)
                    level.server.runCommandSilent(`execute at ${entity.username} run playsound minecraft:block.beacon.activate master @a ~ ~ ~`)
                    level.server.runCommandSilent(`execute at ${entity.username} run playsound minecraft:entity.wither.break_block master @a ~ ~ ~`)
                    level.server.runCommandSilent(`tellraw @a {"text":"${entity.username} has been uncorrupted","color":"dark_red"}`)
                    itemstack.shrink(1)
                } else {
                    level.server.runCommandSilent(`execute at ${entity.username} run playsound minecraft:block.beacon.deactivate master @a ~ ~ ~`)
                    level.server.runCommandSilent(`execute at ${entity.username} run playsound minecraft:item.shield.break master @a ~ ~ ~`)
                }
            } catch (ex) {
                console.log(ex);
            }
            return itemstack
        })
})

StartupEvents.registry('block', event => {
    event
        .create('clear_block')
        .displayName('Clear Block')
        .hardness(1)
        .resistance(1500)
        .requiresTool(false)
        .texture('kubejs:block/clear_block')
        .defaultCutout()

    event
        .create('tube_wall')
        .displayName('Tube Wall')
        .requiresTool(false)
        .texture('kubejs:block/quartz_block_connecting')
        .mapColor('quartz')
        .viewBlocking(true)
        .noValidSpawns(true)
        .unbreakable()

    event
        .create('clear_glass')
        .displayName('Clear Glass')
        .texture("kubejs:block/clear_glass")
        .requiresTool(false)
        .noValidSpawns(true)
        .viewBlocking(true)
        .transparent(true)
        .glassSoundType()
        .defaultCutout()
        .unbreakable()

    event
        .create('water_blocker')
        .displayName('Water Blocker')
        .texture('kubejs:block/clear_block')
        .requiresTool(false)
        .noCollision()
        .transparent(true)
        .viewBlocking(false)
        .defaultTranslucent()
        .unbreakable()
        .item(i => {i.texture("minecraft:item/structure_void")})
})
