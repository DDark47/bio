ServerEvents.basicCommand("persistentdata", e => {
    const params = e.input.split(" ")
    const data = e.server.persistentData
    try {
        switch (params[0]) {
            case "get":
                if (params.length != 2) e.respond("§cMust have param \"key\"!")
                e.respond(data.get(params[1]).getAsString())
                break;
            case "remove":
                if (params.length != 2) e.respond("§cMust have param \"key\"!")
                data.remove(params[1])
                e.respond(`Removed key \`${params[1]}\``)
                break;
            case "set":
                if (params.length != 3) e.respond("§cMust have params \"key\" and \"value\"!")
                data.putString(params[1], params[2])
                e.respond(`Set key \`${params[1]}\` to \`${params[2]}\``)
                break;
            default:
                e.respond("§cParam must be one of \"get\", \"set\", or \"remove\"!")
                break;
        }
        if (params[0] == "get") {
        }
    }
    catch (ex) {
        e.respond("§cAn unexpected error occured trying to execute that command: " + ex)
    }
})
