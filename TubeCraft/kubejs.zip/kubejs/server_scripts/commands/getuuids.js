ServerEvents.basicCommand("getuuids", event => {
    var uuids = [""]
    event.getServer().getMcPlayers().forEach(player => {
        uuids.push(`${player.getUsername()}: ${player.getStringUuid()}`)
    })
    event.respond(uuids.join("\n"))
})
