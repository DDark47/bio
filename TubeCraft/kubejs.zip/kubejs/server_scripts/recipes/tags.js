ServerEvents.tags("item", event => {
    event.add('create:crushed_raw_materials', 'garnished:crushed_salt')
    // event.add('c:dusts', 'kubejs:zinc_dust')
    // event.add('c:dusts/zinc', 'kubejs:zinc_dust')
    event.add('c:dusts/salt', 'garnished:salt_compound')
    event.add('c:compost_materials', 'minecraft:rotten_flesh')

    event.add('minecraft:pickaxes', 'codmod:hard_drive_hammer')
    event.add('minecraft:axes', 'codmod:hard_drive_hammer')
    event.add('minecraft:shovels', 'codmod:hard_drive_hammer')
    event.add('minecraft:pickaxes', 'codmod:cod_pickaxe')
    event.add('minecraft:pickaxes', 'codmod:v1_pickaxe')
    event.add('minecraft:axes', 'codmod:v1_axe')
    event.add('minecraft:hoes', 'codmod:v1_hoe')
    event.add('minecraft:shovels', 'codmod:v1_shovel')

    event.add('c:foods/fruit', 'codmod:banana')
    event.add('c:foods/fruit', 'codmod:cucumber')
    event.add('c:foods/fruit', 'codmod:orange')
    event.add('c:foods/fruit', 'codmod:lemon')
    event.add('c:foods/vegetable', 'codmod:tomato')
    event.add('c:foods/tomato', 'codmod:tomato')
    event.add('c:foods', 'codmod:bun')
    event.add('c:foods', 'codmod:taco')
    event.add('c:foods', 'codmod:baguette')
    event.add('c:foods', 'codmod:realcod')
    event.add('c:foods/golden', 'codmod:golden_cod')
    event.add('c:foods/golden', 'codmod:enchanted_gold_cod')

    const trim_list = [
        'thebrokenscript:n'
    ]
    function trims(material) {
        event.add('minecraft:trim_materials', material)
    }
    trim_list.forEach(m => trims(m));

    const explosive_list = [
        "minecraft:tnt",
        "minecraft:tnt_minecart",
        "supplementaries:bomb",
        "supplementaries:bomb_blue",
        "supplementaries:bomb_spiky",
    ]
    function explosives(material) {
        event.add(`c:explosives`, material)
    }
    explosive_list.forEach(m => explosives(m))
})