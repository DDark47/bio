let $RecipesKubeEvent = Java.loadClass("dev.latvian.mods.kubejs.recipe.RecipesKubeEvent");
let $ItemStack = Java.loadClass("net.minecraft.world.item.ItemStack");

/**
 * @param {$ItemStack} input 
 * @param {$ItemStack} output 
 * @param {$RecipesKubeEvent} event */
function pressing(input, output, event) {
    event.custom({
        "type": "create:pressing",
        "ingredients":
            [{ "item": input }],
        "results":
            [{ "id": output }]
    });
}
