ServerEvents.recipes(event => {
   event.custom({
      "type": "create:crushing",
      "ingredients": [
         {
            "tag": "garnished:stone_types/zultanite/purple"
         }
      ],
      "processing_time": 250,
      "results": [
         {
            "count": 2,
            "chance": 0.06,
            "item": {
               "id": "hexcasting:amethyst_dust"
            }
         },
         {
            "count": 1,
            "chance": 0.02,
            "item": {
               "id": "minecraft:amethyst_shard"
            }
         },
         {
            "count": 1,
            "chance": 0.005,
            "item": {
               "id": "hexcasting:charged_amethyst"
            }
         }
      ]
   })
})
