ServerEvents.recipes(event => {
    event.remove({id: 'minecraft:book'})

    event.shapeless(
        Item.of('minecraft:book', 1),
        [
            '3x minecraft:paper',
            '#c:leathers'
        ]
    )
})
