ServerEvents.recipes(event => {
    event.shaped(
        Item.of("supplementaries:globe", 1),
        [
            "  R",
            "MCG",
            "RGG"
        ],
        {
            "R": {"tag": "c:rods/iron"},
            "C": {"item": "create:cardboard"},
            "G": {"tag": "c:ingots/gold"},
            "M": {"item": "minecraft:filled_map"}
        }
    )
})
