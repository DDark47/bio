ServerEvents.recipes(event => {
    event.shaped(
        Item.of('kubejs:revival_star', 1),
        [
            'ded',
            'ese',
            'dxd'
        ],
        {
            s: '#minecraft:skulls',
            x: 'minecraft:netherite_ingot',
            d: 'minecraft:diamond',
            e: 'create:experience_block'
        }
    )
})
