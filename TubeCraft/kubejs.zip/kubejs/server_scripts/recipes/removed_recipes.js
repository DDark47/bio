ServerEvents.recipes(event => {
    event.remove({ id: 'create:rolling/paper' })
    event.remove({ id: 'create:rolling/bamboo' })
    event.remove({ output: 'create:tree_fertilizer' })

    event.remove({ output: "wands:magic_bag_1" })
    event.remove({ output: "wands:magic_bag_2" })
    event.remove({ output: "wands:magic_bag_3" })

})
