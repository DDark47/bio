let $ScoreAccess = Java.loadClass("net.minecraft.world.scores.ScoreAccess");
let $ScoreHolder = Java.loadClass("net.minecraft.world.scores.ScoreHolder");
let $Entity = Java.loadClass("net.minecraft.world.entity.Entity");

/**
 * @param {$ScoreHolder} scoreHolder
 * @param {string} objective
 * @returns {$ScoreAccess}
 */
function getScore(scoreHolder, objective) {
    const { scoreboard } = scoreHolder
    return scoreboard.getOrCreatePlayerScore(scoreHolder, scoreboard.getObjective(objective)) ?? null
}

// /**
//  * @param {$Entity} entity
//  * @returns {string}
//  */
// function getDimension(entity) {
//     const a = entity.getLevel().getDimension()
//     const b = a.getNamespace()
//     const c = a.getPath()
//     return b + ":" + c
// }

EntityEvents.death((event) => {
    const server = event.server
    if (server === null) return
    if (event.entity.isPlayer() && event.source.actual) {
        if (event.entity.getTeamName() === "Void" && event.source.actual.tags.contains("indignant")) {
            event.entity.block.popItem('kubejs:revival_star')
            server.runCommand(`function tubeutils:fight_end1 {1:"${event.source.actual.username}"}`)
        }
        if (event.source.actual.tags.contains("voltage")) {
            console.error(`CORRUPTING PLAYER ${event.entity.username}`);
            getScore(event.entity, "tbe_deaths").add(1)
            server.runCommandSilent(`execute as @a at ${event.source.actual.username} run playsound thebrokenscript:the_end_is_near master @a ~ ~ ~ 10000`)
            server.runCommandSilent(`execute as ${event.source.actual.username} at @s run function tubeutils:voltage_invisible`)
        }
    }
})

// var respawncoords = [-21, -19, -17, -15, -13, -11, -9]
// var voidlayers = [
//     "thebrokenscript:day_a",
//     "thebrokenscript:null_torture",
//     "codmod:raxxla",
// ]
// LevelEvents.tick((event) => {
//     const server = event.server
//     if (server === null) return
//     if (server.tickCount % 10 === 0) {
//         event.server.players.forEach(p => {
//             const dim = getDimension(p)
//             const pos = p.position()
//             const tags = p.tags
//             if (dim == "thebrokenscript:day_b" && (pos.y <= 40)) {
//                 p.teleportTo("thebrokenscript:day_a", pos.x, 130, pos.z, 0, 0)
//             }
//             if (dim == "thebrokenscript:day_a") {
//                 tags.add("beneathvoid")
//             }
//             if (dim == "thebrokenscript:day_a" && (pos.y <= -100)) {
//                 p.teleportTo("thebrokenscript:null_torture", pos.x, 100, pos.z, 0, 0)
//                 tags.add("beneathvoid")
//             }
//             if (dim == "thebrokenscript:null_torture" && (pos.y <= -100)) {
//                 p.teleportTo("codmod:raxxla", pos.x, 250, pos.z, 0, 0)
//                 tags.add("beneathvoid")
//                 tags.add("beneathvoid1")
//             }

//             if (voidlayers.includes(dim) && !tags.contains("beneathvoid") && !tags.contains("in_facility")) {
//                 p.damage(8, "minecraft:wither")
//             } else if (!voidlayers.includes(dim) && !tags.contains("beneathvoid1")) {
//                 tags.remove("beneathvoid")
//             }
//         })
//     }
//     server.runCommandSilent(`function tubeutils:death_tp {1:"${respawncoords[Math.floor(Math.random() * respawncoords.length)]}"}`)
// })


// ItemEvents.rightClicked(event => {
//     if (event.item.id.startsWith('waystones:') && !event.player.isCreative() && (event.entity.tags.contains("beneathvoid1") || event.server.persistentData.get("facility_enabled") != null)) event.cancel()
// })

// BlockEvents.rightClicked(event => {
//     if (event.item.id.startsWith('waystones:') && !event.player.isCreative() && (event.entity.tags.contains("beneathvoid1") || event.server.persistentData.get("facility_enabled") != null)) event.cancel()
// })
